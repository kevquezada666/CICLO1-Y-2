public class Cup extends StackItem
{
    private Rectangle leftSide;
    private Rectangle rightSide;
    private Rectangle bottom;
    private static final int wall = 10;

    public Cup(int x, int y, int size, String color)
    {
        super(x, y, size, color);

        leftSide = new Rectangle();
        rightSide = new Rectangle();
        bottom = new Rectangle();

        leftSide.changeSize(size, wall);
        leftSide.changeColor(color);
        leftSide.moveHorizontal(x - 70);
        leftSide.moveVertical(y - 15);

        rightSide.changeSize(size, wall);
        rightSide.changeColor(color);
        rightSide.moveHorizontal(x + size - wall - 70);
        rightSide.moveVertical(y - 15);

        bottom.changeSize(wall, size);
        bottom.changeColor(color);
        bottom.moveHorizontal(x - 70);
        bottom.moveVertical(y + size - wall - 15);
    }

    public void makeVisible()
    {
        leftSide.makeVisible();
        rightSide.makeVisible();
        bottom.makeVisible();
    }

    public void makeInvisible()
    {
        leftSide.makeInvisible();
        rightSide.makeInvisible();
        bottom.makeInvisible();
    }

    public void moveVertical(int distance)
    {
        leftSide.moveVertical(distance);
        rightSide.moveVertical(distance);
        bottom.moveVertical(distance);
    }
}