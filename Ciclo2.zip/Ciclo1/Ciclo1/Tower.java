import java.util.ArrayList;

public class Tower
{
    // instance variables - replace the example below with your own
    
    private int width;
    private int maxHeight;
    private boolean visible;
    private Rectangle base;
    private Rectangle heightBase;    
    private ArrayList<StackItem> items;
    private static final int pixels = 10;
    private int axisX = 150;
    private int currentHeight = 0;
    private int baseY = 295;
    private static final int lidHeight = 10;
    private ArrayList<Rectangle> marks;
    private static final String[] COLORS = {"red", "blue", "green", "yellow", "magenta"};

    /**
     * Constructor for objects of class Tower
     */
    public Tower(int width, int maxHeight)
    {
        this.width = width;
        this.maxHeight = maxHeight;
        this.visible = true;
        this.items = new ArrayList<StackItem>();
        this.marks = new ArrayList<Rectangle>();
        this.base = new Rectangle();
        this.heightBase = new Rectangle();
        initializeBase();
        
    }
    public Tower(int cups)
    {
        this(2 * cups - 1, cups * cups);
        for(int i = cups; i >= 1; i--){
            pushCup(i);
        }
    }
    public void initializeBase()
    {
        base.changeSize(2, width * 10);
        base.changeColor("black");
        base.moveVertical(280);
        base.moveHorizontal(-50);
        
        if (visible) {
            base.makeVisible();
        }
        
        heightBase.changeSize(maxHeight * 10, 2);
        heightBase.changeColor("black");
        heightBase.moveVertical(280 - (maxHeight * 10));
        heightBase.moveHorizontal(-50);
        
        if (visible) {
            heightBase.makeVisible();
        }
        axisX = 20 + (width * 10) / 2;
        
        for(int i = 1; i <= maxHeight; i++){
            Rectangle mark = new Rectangle();
            mark.changeSize(2, 5);
            mark.changeColor("black");
            mark.moveHorizontal(-53);
            mark.moveVertical(280 - (i * pixels)); // sin el -15, ya está incluido en yPosition
            marks.add(mark);
            if(visible){
                mark.makeVisible();
            }
        }
    }
    
 
    public void pushCup(int i)
    {
        int size = (2*i - 1) * pixels;
        String color = COLORS[(i-1) % COLORS.length];
        int x = axisX - size/2;
        int y = baseY - currentHeight - size;

        Cup cup = new Cup(x, y, size, color);
        items.add(cup);
        currentHeight += size;

        if(visible){
            cup.makeVisible();
        }
    }
    
    /**
     * Elimina la última taza
     */
    public void popCup()
    {
        if(items.size() == 0){
            return;
        }
        StackItem lastItem = items.get(items.size() - 1);
        lastItem.makeInvisible();
        currentHeight -= lastItem.getSize();
        items.remove(items.size() - 1);
    }
    
    /**
     * Elimina la taza en la posición i
     * @param i posición de la taza a eliminar
     */
    public void removeCup(int i)
    {
        if(i < 1 || i > items.size()){
            return;
        }
        int index = i - 1;
        StackItem removedItem = items.get(index);
        int removedSize = removedItem.getSize();
        removedItem.makeInvisible();
        items.remove(index);
        currentHeight -= removedSize;
        for(int j = index; j < items.size(); j++){
            items.get(j).moveVertical(removedSize);
        }
    }
    
    /**
     * Adiciona una tapa en la posición i
     * @param i posición donde agregar la tapa
     */
    public void pushLid(int i)
    {
        int size = (2*i - 1) * pixels;
        String color = COLORS[(i-1) % COLORS.length];
        int x = axisX - size/2;
        int y = baseY - currentHeight - lidHeight;

        Lid lid = new Lid(x, y, size, color);
        items.add(lid);
        currentHeight += lidHeight;

        if(visible){
            lid.makeVisible();
        }
    }
    
    /**
     * Elimina la última tapa
     */
    public void popLid()
    {
        if(items.size() == 0){
            return;
        }

        Object last = items.get(items.size() - 1);

        if(!(last instanceof Lid)){
            return;
        }

        Lid lastLid = (Lid) last;
        lastLid.makeInvisible();
        currentHeight -= lidHeight;
        items.remove(items.size() - 1);
    }
    
    /**
     * Elimina la tapa en la posición i
     * @param i posición de la tapa a eliminar
     */
    public void removeLid(int i)
    {
        if(i < 1 || i > items.size()){
            return;
        }
        int index = i - 1;
        StackItem item = items.get(index);
        if(!(item instanceof Lid)){
            return;
        }
        item.makeInvisible();
        items.remove(index);
        currentHeight -= lidHeight;
        for(int j = index; j < items.size(); j++){
            items.get(j).moveVertical(lidHeight);
        }
    }
    
    /**
     * Ordena los elementos de mayor a menor (solo los que quepan)
     */
    public void orderTower()
    {
        ArrayList<StackItem> oldItems = new ArrayList<StackItem>(items);
        for(StackItem item : oldItems){
            item.makeInvisible();
        }
        items.clear();
        currentHeight = 0;

        ArrayList<Cup> cups = new ArrayList<Cup>();
        ArrayList<Lid> lids = new ArrayList<Lid>();
        for(StackItem item : oldItems){
            if(item instanceof Cup) cups.add((Cup) item);
            else lids.add((Lid) item);
        }

        cups.sort((a, b) -> b.getSize() - a.getSize());

        for(Cup cup : cups){
            int iCup = (cup.getSize() / pixels + 1) / 2;
            pushCup(iCup);
            for(Lid lid : lids){
                if(lid.getSize() == cup.getSize()){
                    int iLid = (lid.getSize() / pixels + 1) / 2;
                    pushLid(iLid);
                    lids.remove(lid);
                    break;
                }
            }
        }

        for(Lid lid : lids){
            int iLid = (lid.getSize() / pixels + 1) / 2;
            pushLid(iLid);
        }
    }
    
    /**
     * Invierte el orden de los elementos (solo los que quepan)
     */
    public void reverseTower()
    {
        ArrayList<StackItem> oldItems = new ArrayList<StackItem>(items);
        for(StackItem item : oldItems){
            item.makeInvisible();
        }
        items.clear();
        currentHeight = 0;

        ArrayList<Cup> cups = new ArrayList<Cup>();
        ArrayList<Lid> lids = new ArrayList<Lid>();
        for(StackItem item : oldItems){
            if(item instanceof Cup) cups.add((Cup) item);
            else lids.add((Lid) item);
        }

        // Único cambio respecto a orderTower: menor a mayor
        cups.sort((a, b) -> a.getSize() - b.getSize());

        for(Cup cup : cups){
            int iCup = (cup.getSize() / pixels + 1) / 2;
            pushCup(iCup);
            for(Lid lid : lids){
                if(lid.getSize() == cup.getSize()){
                    int iLid = (lid.getSize() / pixels + 1) / 2;
                    pushLid(iLid);
                    lids.remove(lid);
                    break;
                }
            }
        }

        for(Lid lid : lids){
            int iLid = (lid.getSize() / pixels + 1) / 2;
            pushLid(iLid);
        }
    }
    
    /**
     * Consulta la altura actual de los elementos apilados
     * @return altura total en cm
     */
    public int height()
    {
        return currentHeight / pixels;
    }
    
    /**
     * Consulta qué tazas están tapadas
     * @return array con índices de las tazas tapadas
     */
    public int[] lidedCups()
    {
        ArrayList<Integer> lided = new ArrayList<Integer>();
        int cupCount = 0;

        for(int i = 0; i < items.size(); i++){
            if(items.get(i) instanceof Cup){
                cupCount++;
                if(i + 1 < items.size() && items.get(i + 1) instanceof Lid){
                    Lid next = (Lid) items.get(i + 1);
                    Cup current = (Cup) items.get(i);
                    if(next.getSize() == current.getSize()){
                        lided.add(cupCount);
                    }
                }
            }
        }

        int[] result = new int[lided.size()];
        for(int i = 0; i < lided.size(); i++){
            result[i] = lided.get(i);
        }
        return result;
    }
    
    /**
     * Consulta información de los elementos apilados
     * @return array con strings "tipo número" (ej: "Cup 1", "Lid 1")
     */
    public String[][] stackingItems()
    {
        String[][] result = new String[items.size()][2];
        int cupCount = 0;
        int lidCount = 0;

        for(int i = 0; i < items.size(); i++){
            if(items.get(i) instanceof Cup){
                cupCount++;
                result[i][0] = "cup";
                result[i][1] = String.valueOf(cupCount);
            } else {
                lidCount++;
                result[i][0] = "lid";
                result[i][1] = String.valueOf(lidCount);
            }
        }
        return result;
    }
    
    /**
     * Hace visible el simulador
     */
    public void makeVisible()
    {
        this.visible = true;
        base.makeVisible();
        heightBase.makeVisible();
        for(StackItem item : items){
            item.makeVisible();
        }
        for(Rectangle mark : marks){
            mark.makeVisible();
        }
    }
    
    /**
     * Hace invisible el simulador
     */
    public void makeInvisible()
    {
        this.visible = false;
        base.makeInvisible();
        heightBase.makeInvisible();
        for(StackItem item : items){
            item.makeInvisible();
        }
        for(Rectangle mark : marks){
            mark.makeInvisible();
        }
    }
    
    /**
     * Termina el simulador
     */
    public void exit()
    {
        makeInvisible();
        items.clear();
        currentHeight = 0;
    }
    
    private int findItem(String[] identifier)
    {
        int count = 0;
        String type = identifier[0];
        int number = Integer.parseInt(identifier[1]);

        for(int i = 0; i < items.size(); i++){
            if(type.equals("cup") && items.get(i) instanceof Cup){
                count++;
                if(count == number) return i;
            } else if(type.equals("lid") && items.get(i) instanceof Lid){
                count++;
                if(count == number) return i;
            }
        }
        return -1; // no encontrado
    }
    
    private int getYAt(int index)
    {
        int h = 0;
        for(int i = 0; i < index; i++){
            if(items.get(i) instanceof Cup){
                h += items.get(i).getSize();
            } else {
                h += lidHeight;
            }
        }
        return baseY - h - (items.get(index) instanceof Cup ? 
                            items.get(index).getSize() : lidHeight);
    }

    public void swap(String[] o1, String[] o2)
    {
        int index1 = findItem(o1);
        int index2 = findItem(o2);

        if(index1 == -1 || index2 == -1){
            return;
        }

        StackItem item1 = items.get(index1);
        StackItem item2 = items.get(index2);

        int y1 = getYAt(index1);
        int y2 = getYAt(index2);

        items.set(index1, item2);
        items.set(index2, item1);

        item1.moveVertical(y2 - y1);
        item2.moveVertical(y1 - y2);
    }
    
    public void cover()
    {
        for(int i = 0; i < items.size(); i++){
            if(items.get(i) instanceof Cup){
                Cup cup = (Cup) items.get(i);
                for(int j = i + 2; j < items.size(); j++){
                    if(items.get(j) instanceof Lid){
                        Lid lid = (Lid) items.get(j);
                        if(lid.getSize() == cup.getSize()){
                            // calcular Y antes de mover
                            int yLid = getYAt(j);
                            int yTarget = getYAt(i + 1) - lidHeight + 
                                      (items.get(i+1) instanceof Cup ? 
                                       items.get(i+1).getSize() : lidHeight);
                            items.remove(j);
                            items.add(i + 1, lid);
                            lid.moveVertical(getYAt(i+1) - yLid);
                            // reposicionar elementos desplazados
                            for(int k = i + 2; k <= j; k++){
                                items.get(k).moveVertical(-lidHeight);
                            }
                            break;
                        }
                    }
                }
            }
        }
    }
    
    private String[] findIdentifier(int index)
    {
        int count = 0;
        StackItem target = items.get(index);
        for(int i = 0; i <= index; i++){
            if(target instanceof Cup && items.get(i) instanceof Cup) count++;
            else if(target instanceof Lid && items.get(i) instanceof Lid) count++;
        }
        String type = target instanceof Cup ? "cup" : "lid";
        return new String[]{type, String.valueOf(count)};
    }
    /**
     * ¿Validar si una operación se puede realizar?
     * @return true si la última operación fue exitosa
     */
    public boolean ok()
    {
        // TODO: Implementar
        return true;
    }
    
}