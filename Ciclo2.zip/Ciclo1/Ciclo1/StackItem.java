public abstract class StackItem
{
    protected int x;
    protected int y;
    protected int size;
    protected String color;
    protected static final int pixels = 10;

    public StackItem(int x, int y, int size, String color)
    {
        this.x = x;
        this.y = y;
        this.size = size;
        this.color = color;
    }

    public abstract void makeVisible();
    public abstract void makeInvisible();
    public abstract void moveVertical(int distance);

    public int getSize()
    {
        return size;
    }

    public String getColor()
    {
        return color;
    }
}