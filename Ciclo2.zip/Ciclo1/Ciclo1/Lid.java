public class Lid extends StackItem
{
    private Rectangle top;
    private static final int height = 1 * pixels;

    public Lid(int x, int y, int size, String color)
    {
        super(x, y, size, color);

        top = new Rectangle();
        top.changeSize(height, size);
        top.changeColor(color);
        top.moveHorizontal(x - 70);
        top.moveVertical(y - 15);
    }

    public void makeVisible()
    {
        top.makeVisible();
    }

    public void makeInvisible()
    {
        top.makeInvisible();
    }

    public void moveVertical(int distance)
    {
        top.moveVertical(distance);
    }
}